/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: December 11, 2021
 */

/**
 * A program to test the Basketball Player class.
 *
 * @author CJ Vergel
 * @version 1.0
 */
public class BasketballPlayerTests
{
	public static void main(String[] args)
	{
		System.out.println("BasketballPlayer(String, int)");

		System.out.println("Test #1 - Initialize the name.");
		constructor_initializeName();

		System.out.println("\nTest #2 - Initialize the number.");
		constructor_initializeNumber();

		System.out.println("\nTest #3 - Initialize the free throws.");
		constructor_initializeFreeThrows();

		System.out.println("\nTest #4 - Initialize the field goals.");
		constructor_initializeFieldGoals();

		System.out.println("\nTest #5 - Initialize the three pointers.");
		constructor_initializeThreePointers();

		System.out.println("\nsetName(String)");

		System.out.println("Test #1 - Updates the state of name.");
		setName_updatesStateOfName();

		System.out.println("\nsetNumber(int)");

		System.out.println("Test #1 - Updates the state of number.");
		setNumber_updatesStateOfNumber();

		System.out.println("\nsetFreeThrows(int)");

		System.out.println("Test #1 - Updates the state of free throws.");
		setFreeThrows_updatesStateOfFreeThrows();

		System.out.println("\nsetFieldGoals(int)");

		System.out.println("Test #1 - Updates the state of field goals.");
		setFieldGoals_updatesStateOfFieldGoals();

		System.out.println("\nsetThreePointers(int)");

		System.out.println("Test #1 - Updates the state of three pointers.");
		setThreePointers_updatesStateOfThreePointers();

		System.out.println("\ngetPoints(int)");

		System.out.println("Test #1 - Returns the correct number of points.");
		getPoints_returnsCorrectNumberOfPoints();

		System.out.println("\ntoString()");

		System.out.println("Test #1 - Returns the correct String representation.");
		toString_returnsStringRepresentation();

	}

	/*
	 * Constructor - BasketballPlayer(String, int)
	 */

	public static void constructor_initializeName()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);

		// Confirm
		String expected = "Steph";
		String actual = target.getName();

		System.out.printf("Expected: %s\nActual: %s\n", expected, actual);
	}

	public static void constructor_initializeNumber()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);

		// Confirm
		int expected = 30;
		int actual = target.getNumber();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor_initializeFreeThrows()
	{
		// Setup test data
		String name = "Michael";
		int number = 23;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);

		// Confirm
		int expected = 0;
		int actual = target.getFreeThrows();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor_initializeFieldGoals()
	{
		// Setup test data
		String name = "Michael";
		int number = 23;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);

		// Confirm
		int expected = 0;
		int actual = target.getFieldGoals();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor_initializeThreePointers()
	{
		// Setup test data
		String name = "Michael";
		int number = 23;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);

		// Confirm
		int expected = 0;
		int actual = target.getThreePointers();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setName_updatesStateOfName()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);

		// Act
		target.setName("Michael");

		// Confirm
		String expected = "Michael";
		String actual = target.getName();

		System.out.printf("Expected: %s\nActual: %s\n", expected, actual);
	}

	public static void setNumber_updatesStateOfNumber()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);

		// Act
		target.setNumber(23);

		// Confirm
		int expected = 23;
		int actual = target.getNumber();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setFreeThrows_updatesStateOfFreeThrows()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);

		// Act
		target.setFreeThrows(15);

		// Confirm
		int expected = 15;
		int actual = target.getFreeThrows();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setFieldGoals_updatesStateOfFieldGoals()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);

		// Act
		target.setFieldGoals(5);

		// Confirm
		int expected = 5;
		int actual = target.getFieldGoals();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setThreePointers_updatesStateOfThreePointers()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);

		// Act
		target.setThreePointers(10);

		// Confirm
		int expected = 10;
		int actual = target.getThreePointers();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void getPoints_returnsCorrectNumberOfPoints()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		// Act
		BasketballPlayer target = new BasketballPlayer(name, number);
		target.setFreeThrows(16);
		target.setFieldGoals(4);
		target.setThreePointers(12);

		// Confirm
		int expected = 60;
		int actual = target.getPoints();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void toString_returnsStringRepresentation()
	{
		// Setup test data
		String name = "Steph";
		int number = 30;

		BasketballPlayer target = new BasketballPlayer(name, number);
		target.setFreeThrows(14);
		target.setFieldGoals(6);
		target.setThreePointers(8);

		// Act
		String actual = target.toString();

		// Confirm
		String expected = "Basketball Player: Steph [30], Points: 50";

		System.out.printf("Expected:%n%s%nActual:%n%s%n", expected, actual);
	}
}
