/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: December 11, 2021
 * Updated: December 12, 2021
 */

/**
 * Represents a Player on a sports team.
 *
 * @author CJ Vergel
 * @version 1.1
 */
public abstract class Player
{
	// Declaring variables.
	private String name;
	private int number;

	/**
	 * Initializes a new instance of the Player class with the specified name and number.
	 *
	 * @param name The player's name.
	 * @param number The player's number.
     */
	public Player(String name, int number)
	{
		this.setName(name);
		this.setNumber(number);
	}

	/**
	 * Returns the name of the player.
	 *
	 * @return name The name of the player.
	 */
	public String getName()
	{
		return this.name;
	}

    /**
     * Sets the name of the player.
     *
     * @param name The player's name.
     */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * Returns the player's jersey number.
	 *
	 * @return number The player's jersey number.
	 */
	public int getNumber()
	{
		return this.number;
	}

    /**
     * Sets the player's jersey number.
     *
     * @param number The player's jersey number.
     */
	public void setNumber(int number)
	{
		this.number = number;
	}

	/**
	 * Returns the total number of points accumulated by the player.
	 *
	 * @return points The total number of points accumulated by the player.
	 */
	public abstract int getPoints();

	/**
	 * Returns the String representation of the player.
	 *
	 * @return The String representation of the player.
	 */
	public String toString()
	{
		return String.format("%s [%d]", name, number);
	}
}