/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: November 27, 2021
 * Updated: November 30, 2021
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;
/**
 * A program to test an ArrayList that stores three TeamShotOnGoalPercentages objects.
 *
 * @author CJ Vergel
 * @version 1.1
 */
public class ArrayListClient
{
	public static void main(String[] args)
	{
		// Instantiating the ArrayList.
		ArrayList<TeamShotOnGoalPercentages> list =
			new ArrayList<TeamShotOnGoalPercentages>();

		// Instantiating the Scanner.
		Scanner keyboard = new Scanner(System.in);

		// Prompt the user for number of players on the team.
		System.out.println("Enter the number of players per team: ");

		// Declaring variable as the integer that the user inputted.
		int numberOfPlayers = keyboard.nextInt();

		// Closing the Scanner.
		keyboard.close();

		// Instantiating the random class.
		Random rand = new Random();

		// Assigning random values to the Array objects to the first team.
		double[] team1 = new double[numberOfPlayers];
		double[] team2 = new double[numberOfPlayers];
		double[] team3 = new double[numberOfPlayers];

		// For loop to assign a random percentage to each player.
		for ( int a = 0; a < numberOfPlayers; a++ )
		{
			int j = 1;
			for ( int i = 0; i < numberOfPlayers; i++)
			{
				if ( j <= (numberOfPlayers) )
				{
					team1[i] = rand.nextDouble();
				}

				if ( j <= (2*numberOfPlayers))
				{
					team2[i] = rand.nextDouble();
				}

				if ( j <= (3*numberOfPlayers) )
				{
					team3[i] = rand.nextDouble();
				}
				j++;
			}
		}
		// Adding the three new TeamShotOnGoalPercentages objects to the ArrayList.
		for ( int a = 0; a < numberOfPlayers; a++ )
		{
			if ( a == 0 )
			{
				list.add(new TeamShotOnGoalPercentages(team1));
			}

			if ( a == 1 )
			{
				list.add(new TeamShotOnGoalPercentages(team2));
			}

			if ( a == 2 )
			{
				list.add(new TeamShotOnGoalPercentages(team3));
			}
		}

		// Enhanced For loop to print each of the TeamShotOnGoalPercentages objects.
		for ( TeamShotOnGoalPercentages percent : list )
		{
			System.out.println(percent);
		}

		// Printing a line to show the value of the final element in the ArrayList.
		System.out.println("LAST ELEMENT BEFORE REMOVE:\n" + list.get( list.size() - 1 ));

		// Removing the final object from the ArrayList.
		list.remove(list.size() - 1);

		System.out.println("LAST ELEMENT AFTER REMOVE:");

		// Trimming the list
		list.trimToSize();

		// Printing a line to show the value of the final element in the ArrayList.
		System.out.println(list.get( list.size() - 1) );
	}
}