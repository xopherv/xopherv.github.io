﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-03-15
 * Updated: 2022-04-10
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vergel.CJ.RRCAGApp
{
    public partial class CarWashInvoiceForm : ACE.BIT.ADEV.Forms.CarWashInvoiceForm
    {
        private BindingSource invoiceSource;

        public CarWashInvoiceForm(BindingSource source)
        {
            this.invoiceSource = source;

            InitializeComponent();

            BindControls();
        }

        private void BindControls()
        {
            Binding packageBind = new Binding("Text", this.invoiceSource, "PackageCost");
            packageBind.FormattingEnabled = true;
            packageBind.FormatString = "C";
            this.lblPackagePrice.DataBindings.Add(packageBind);

            Binding fragranceBind = new Binding("Text", this.invoiceSource, "FragranceCost");
            fragranceBind.FormattingEnabled = true;
            fragranceBind.FormatString = "N2";
            this.lblFragrancePrice.DataBindings.Add(fragranceBind);

            Binding subtotalBind = new Binding("Text", this.invoiceSource, "Subtotal");
            subtotalBind.FormattingEnabled = true;
            subtotalBind.FormatString = "C";
            this.lblSubtotal.DataBindings.Add(subtotalBind);

            Binding pstBind = new Binding("Text", this.invoiceSource, "ProvincialSalesTaxCharged");
            pstBind.FormattingEnabled = true;
            pstBind.FormatString = "N2";
            this.lblProvincialSalesTax.DataBindings.Add(pstBind);

            Binding gstBind = new Binding("Text", this.invoiceSource, "GoodsAndServicesTaxCharged");
            gstBind.FormattingEnabled = true;
            gstBind.FormatString = "N2";
            this.lblGoodsAndServicesTax.DataBindings.Add(gstBind);

            Binding totalBind = new Binding("Text", this.invoiceSource, "Total");
            totalBind.FormattingEnabled = true;
            totalBind.FormatString = "C";
            this.lblTotal.DataBindings.Add(totalBind);
        }
    }
}
