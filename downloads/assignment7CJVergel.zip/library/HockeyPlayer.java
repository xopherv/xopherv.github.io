/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: December 11, 2021
 */

/**
 * Represents a hockey player.
 *
 * @author CJ Vergel
 * @version 1.0
 */
public class HockeyPlayer extends Player
{
	// Declaring variables.
	private int goals;
	private int assists;

	/**
	 * Initializes a new instance of the HockeyPlayer class with the specified
	 * name and number with goals and assists set to 0.
	 *
	 * @param name The player's name.
	 * @param number The player's number.
	 */
	public HockeyPlayer(String name, int number)
	{
		super(name, number);

		goals = 0;
		assists = 0;
	}

	/**
	 * Initializes a new instance of the HockeyPlayer class with the specified
	 * name, number, goals, and assists.
	 *
	 * @param name The player's name.
	 * @param number The player's number.
	 * @param goals The number of goals scored by the hockey player.
	 * @param assists The number of assists made by the hockey player.
	 */
	public HockeyPlayer(String name, int number, int goals, int assists)
	{
		super(name, number);

		this.goals = goals;
		this.assists = assists;
	}

	/**
	 * Returns the number of goals scored by the hockey player.
	 *
	 * @return goals The number of goals scored by the hockey player.
	 */
	public int getGoals()
	{
		return this.goals;
	}

	/**
	 * Sets the number of goals scored by the hockey player.
	 *
	 * @param goals The number of goals scored by the hockey player.
	 */
	public void setGoals(int goals)
	{
		this.goals = goals;
	}

	/**
	 * Returns the number of assists made by the hockey player.
	 *
	 * @return assists The number of assists made by the hockey player.
	 */
	public int getAssists()
	{
		return this.assists;
	}

	/**
	 * Sets the number of assists made by the hockey player.
	 *
	 * @param assists The number of assists made by the hockey player.
	 */
	public void setAssists(int assists)
	{
		this.assists = assists;
	}

	/**
	 * Returns the number of points accumulated by the hockey player.
	 *
	 * @return points The number of points accumulated by the hockey player.
	 */
	public int getPoints()
	{
		int points;

		points = this.assists + this.goals;

		return points;
	}

	/**
	 * Returns the String representation of the player.
	 *
	 * @return The String representation of the player.
	 */
	public String toString()
	{
		return String.format("Hockey Player - %s [%d], Points: %d", getName(), getNumber(), getPoints());
	}
}