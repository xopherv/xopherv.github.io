﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-03-15
 * Updated: 2022-04-22
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ACE.BIT.ADEV;
using Vergel.CJ.Business;

namespace Vergel.CJ.RRCAGApp
{
    /// <summary>
    /// Provides a form in which you may open other child forms.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Subscribes to the Events of the Main form.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();

            this.mnuFileExit.Click += MnuFileExit_Click;
            this.mnuHelpAbout.Click += MnuHelpAbout_Click;
            this.mnuFileOpenSalesQuote.Click += MnuFileOpenSalesQuote_Click;
            this.mnuDataVehicle.Click += MnuDataVehicle_Click;
            this.mnuFileOpenCarWash.Click += MnuFileOpenCarWash_Click;
        }

        private void MnuFileOpenCarWash_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists("fragrances.txt"))
                {
                    CarWashForm form = new CarWashForm();
                    form.MdiParent = this;
                    form.Show();
                }
                else if (!File.Exists("fragrances.txt"))
                {
                    MessageBox.Show("Fragrances data file not found.", "Data File Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("An error occurred while reading the data file.", 
                    "Data File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MnuDataVehicle_Click(object sender, EventArgs e)
        {
            VehicleDataForm form = new VehicleDataForm();

            form.MdiParent = this;

            if (File.Exists("AMDatabase.mdb"))
            {
                form.Show();
            }
        }

        /// <summary>
        /// Handles the Click event of the Sales Quote menu item.
        /// </summary>
        private void MnuFileOpenSalesQuote_Click(object sender, EventArgs e)
        {
            SalesQuoteForm form = new SalesQuoteForm();

            form.MdiParent = this;

            form.Show();
        }

        /// <summary>
        /// Handles the Click event of the about menu item.
        /// </summary>
        private void MnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutForm form;

            form = new AboutForm();

            form.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the exit menu item.
        /// </summary>
        private void MnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
