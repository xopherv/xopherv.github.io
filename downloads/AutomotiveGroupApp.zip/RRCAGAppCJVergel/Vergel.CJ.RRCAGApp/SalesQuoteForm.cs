﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-03-15
 * Updated: 2022-03-24
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ACE.BIT.ADEV;
using Vergel.CJ.Business;

namespace Vergel.CJ.RRCAGApp
{
    /// <summary>
    /// Provides functionality that calculates a Sales Quote 
    /// based on the values provided and options selected.
    /// </summary>
    public partial class SalesQuoteForm : Form
    {
        /// <summary>
        /// Subscribes to the events of the SalesQuote Form.
        /// </summary>
        public SalesQuoteForm()
        {
            InitializeComponent();

            // Subscribing to events for buttons being clicked.
            this.btnCalculate.Click += BtnCalculate_Click;
            this.btnReset.Click += BtnReset_Click;

            // Subscribing to events for text being changed.
            this.txtVehicleSalePrice.TextChanged += TxtVehicleSalePrice_TextChanged;
            this.txtTradeInValue.TextChanged += TxtTradeInValue_TextChanged;

            // Subscribing to events for other controls being changed.
            this.chkStereoSystem.CheckedChanged += Control_ValueChanged;
            this.chkLeatherInterior.CheckedChanged += Control_ValueChanged;
            this.chkComputerNavigation.CheckedChanged += Control_ValueChanged;
            this.radStandard.CheckedChanged += Control_ValueChanged;
            this.radPearlized.CheckedChanged += Control_ValueChanged;
            this.radCustomized.CheckedChanged += Control_ValueChanged;
            this.nudYears.ValueChanged += Control_ValueChanged;
            this.nudRate.ValueChanged += Control_ValueChanged;
        }

        /// <summary>
        /// Handles the Click event for the reset button.
        /// </summary>
        private void BtnReset_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you want to reset the form?", "Reset Form", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (result == DialogResult.Yes)
            {
                ClearOutputs();
                Reset();
                this.txtVehicleSalePrice.Focus();
            }
        }

        /// <summary>
        /// Handles the Value Changed event for various controls on the form.
        /// </summary>
        private void Control_ValueChanged(object sender, EventArgs e)
        {
            if (!(this.lblFinanceMonthlyPayment.Text == string.Empty))
            {
                Calculate();
            }
        }

        /// <summary>
        /// Handles the Text Changed event for the trade-in value text.
        /// </summary>
        private void TxtTradeInValue_TextChanged(object sender, EventArgs e)
        {
            this.errorProvider.SetError(this.txtTradeInValue, string.Empty);
            ClearOutputs();
        }

        /// <summary>
        /// Handles the Text Changed event for the vehicle sale price text.
        /// </summary>
        private void TxtVehicleSalePrice_TextChanged(object sender, EventArgs e)
        {
            this.errorProvider.SetError(this.txtVehicleSalePrice, string.Empty);
            ClearOutputs();
        }

        /// <summary>
        /// Handles the Click event for the calculate button.
        /// </summary>
        private void BtnCalculate_Click(object sender, EventArgs e)
        { 
            Calculate();
        }

        /// <summary>
        /// A method to validate the vehicle sale price and return the value.
        /// </summary>
        /// <returns>The value assigned to vehicle sale price.</returns>
        private decimal ValidateVehicleSalePrice()
        {
            decimal vehicleSalePrice = 0;

            try
            {
                vehicleSalePrice = decimal.Parse(this.txtVehicleSalePrice.Text);

                if (decimal.Parse(txtVehicleSalePrice.Text) <= 0)
                {
                    this.errorProvider.SetIconPadding(this.txtVehicleSalePrice, 3);
                    this.errorProvider.SetError(this.txtVehicleSalePrice, 
                        "Vehicle price cannot be less than or equal to 0.");
                }
            }
            catch (FormatException)
            {
                this.errorProvider.SetIconPadding(this.txtVehicleSalePrice, 3);
                this.errorProvider.SetError(this.txtVehicleSalePrice,
                    "Vehicle price cannot contain letters or special characters.");
            }

            if (txtVehicleSalePrice.Text == string.Empty)
            {
                this.errorProvider.SetIconPadding(this.txtVehicleSalePrice, 3);
                this.errorProvider.SetError(this.txtVehicleSalePrice, 
                    "Vehicle price is a required field.");
            }

            return vehicleSalePrice;
        }

        /// <summary>
        /// A method to validate and return the trade-in value.
        /// </summary>
        /// <returns>The value assigned to trade-in value.</returns>
        private decimal ValidateTradeInValue()
        {
            decimal tradeInValue = 0;

            try
            {
                tradeInValue = decimal.Parse(this.txtTradeInValue.Text);

                if (decimal.Parse(txtTradeInValue.Text) < 0)
                {
                    this.errorProvider.SetIconPadding(this.txtTradeInValue, 3);
                    this.errorProvider.SetError(this.txtTradeInValue, "Trade-in value cannot be less than 0.");
                }

                if (this.errorProvider.GetError(this.txtVehicleSalePrice).Equals(string.Empty))
                {
                    if (decimal.Parse(txtTradeInValue.Text) > decimal.Parse(txtVehicleSalePrice.Text))
                    {
                        this.errorProvider.SetIconPadding(this.txtTradeInValue, 3);
                        this.errorProvider.SetError(this.txtTradeInValue,
                            "Trade-in value cannot exceed the vehicle sale price.");
                    }
                }
            }
            catch (FormatException)
            {
                this.errorProvider.SetIconPadding(this.txtTradeInValue, 3);
                this.errorProvider.SetError(this.txtTradeInValue, 
                    "Trade-in value cannot contain letters or special characters.");
            }

            if (txtTradeInValue.Text == string.Empty)
            {
                this.errorProvider.SetIconPadding(this.txtTradeInValue, 3);
                this.errorProvider.SetError(this.txtTradeInValue, "Trade-in value is a required field.");
            }

            return tradeInValue;
        }

        /// <summary>
        /// A method to clear the output labels.
        /// </summary>
        private void ClearOutputs()
        {
            this.lblSummaryVehicleSalePrice.Text = string.Empty;
            this.lblSummaryTradeIn.Text = string.Empty;
            this.lblSummarySalesTax.Text = string.Empty;
            this.lblSummaryOptions.Text = string.Empty;
            this.lblSummarySubtotal.Text = string.Empty;
            this.lblSummaryTotal.Text = string.Empty;
            this.lblSummaryAmountDue.Text = string.Empty;
            this.lblFinanceMonthlyPayment.Text = string.Empty;
        }

        /// <summary>
        /// A method to reset the form to its initial state.
        /// </summary>
        private void Reset()
        {
            this.txtVehicleSalePrice.Text = string.Empty;
            this.txtTradeInValue.Text = "0";

            this.chkStereoSystem.Checked = false;
            this.chkLeatherInterior.Checked = false;
            this.chkComputerNavigation.Checked = false;

            this.radStandard.Checked = true;
            this.radPearlized.Checked = false;
            this.radCustomized.Checked = false;

            this.nudRate.Value = 5;
            this.nudYears.Value = 1;
        }

        /// <summary>
        /// A method to check and return the accessories that were chosen.
        /// </summary>
        /// <returns>The chosen accessories.</returns>
        private Accessories CheckAccessories()
        {
            Accessories accessoriesChosen = Accessories.None;

            if (this.chkStereoSystem.Checked && 
                !this.chkLeatherInterior.Checked && 
                !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.StereoSystem;
            }

            else if (!this.chkStereoSystem.Checked && 
                this.chkLeatherInterior.Checked && 
                !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.LeatherInterior;
            }

            else if (!this.chkStereoSystem.Checked && 
                !this.chkLeatherInterior.Checked && 
                this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.ComputerNavigation;
            }

            else if (this.chkStereoSystem.Checked && 
                this.chkLeatherInterior.Checked && 
                !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.StereoAndLeather;
            }

            else if (!this.chkStereoSystem.Checked && 
                this.chkLeatherInterior.Checked && 
                this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.LeatherAndNavigation;
            }

            else if (this.chkStereoSystem.Checked && 
                !this.chkLeatherInterior.Checked && 
                this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.StereoAndNavigation;
            }

            else if (this.chkStereoSystem.Checked && 
                this.chkLeatherInterior.Checked && 
                this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.All;
            }

            return accessoriesChosen;
        }

        /// <summary>
        /// A method to check and return the exterior finish that was chosen.
        /// </summary>
        /// <returns>The chosen exterior finish.</returns>
        private ExteriorFinish CheckExteriorFinish()
        {
            ExteriorFinish exteriorFinishChosen = ExteriorFinish.None;

            if (this.radStandard.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Standard;
            }

            else if (this.radPearlized.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Pearlized;
            }

            else if (this.radCustomized.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Custom;
            }

            return exteriorFinishChosen;
        }

        /// <summary>
        /// A method to populate the Sales Quote Form's output labels 
        /// through calculations using the values provided.
        /// </summary>
        private void Calculate()
        {
            decimal vehicleSalePrice = ValidateVehicleSalePrice();
            decimal tradeInValue = ValidateTradeInValue();
            decimal salesTaxRate = 0.12m;
            int periods = decimal.ToInt32((nudYears.Value * 12));
            decimal rate = (nudRate.Value / 12) / 100;
            Accessories accessoriesChosen = CheckAccessories();
            ExteriorFinish exteriorFinishChosen = CheckExteriorFinish();

            if (this.errorProvider.GetError(this.txtVehicleSalePrice).Equals(string.Empty) && 
                this.errorProvider.GetError(this.txtTradeInValue).Equals(string.Empty))
            {
                SalesQuote salesQuote = new SalesQuote(vehicleSalePrice, tradeInValue, salesTaxRate, accessoriesChosen, exteriorFinishChosen);

                this.lblSummaryVehicleSalePrice.Text = salesQuote.VehicleSalePrice.ToString("C");
                this.lblSummaryTradeIn.Text = ((salesQuote.TradeInAmount) * -1).ToString("N");
                this.lblSummarySalesTax.Text = salesQuote.SalesTax.ToString("N");
                this.lblSummaryTotal.Text = salesQuote.Total.ToString("C");
                this.lblSummarySubtotal.Text = salesQuote.SubTotal.ToString("C");
                this.lblSummaryOptions.Text = salesQuote.TotalOptions.ToString("N");
                this.lblSummaryAmountDue.Text = salesQuote.AmountDue.ToString("C");
                this.lblFinanceMonthlyPayment.Text = (Financial.GetPayment(rate, periods, salesQuote.AmountDue).ToString("C"));
            }
        }
    }
}
