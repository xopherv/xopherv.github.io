/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: November 27, 2021
 * Updated: November 30, 2021
 */
import java.text.DecimalFormat;
/**
 * Represents a team's percentages for shots on goal.
 *
 * @author CJ Vergel
 * @version 1.1
 */
public class TeamShotOnGoalPercentages
{
	private double[] percentages;

	/**
	 * Initializes a new instance of the TeamShotOnGoalPercentages
	 * class with the specified number of players.
	 *
	 * @param numberOfPlayers The number of players on the team.
	 */
	public TeamShotOnGoalPercentages(int numberOfPlayers)
	{
		this.percentages = new double[numberOfPlayers];
	}

	/**
	 * Initializes a new instance of the TeamShotOnGoalPercentages
	 * class with the specified player�s shot on goal percentages.
	 *
	 * @param percentages The shot on goal percentages for each player on the team.
	 */
	public TeamShotOnGoalPercentages(double[] percentages)
	{
		this.percentages = copyPercentages(percentages);
	}

	/**
	 * Returns a copy of the specified array.
	 *
	 * @param percentages The array of percentage values to be copied.
	 * @return A copy of the specified array.
	 */
	private double[] copyPercentages(double[] percentagesToCopy)
	{
		double[] percentagesCopy = new double[percentagesToCopy.length];

		// For loop to copy the elements of the original array.
		for (int i = 0; i < percentagesToCopy.length; i++)
		{
			percentagesCopy[i] = percentagesToCopy[i];
		}

		return percentagesCopy;
	}

	/**
	 * Returns a copy of the shot on goal percentages.
	 *
	 * @return A copy of the shot on goal percentages.
	 */
	public double[] getPercentages()
	{
		double[] copy = copyPercentages(percentages);

		return copy;
	}

	/**
	 * Sets the team�s percentages.
	 *
	 * @param percentages The shot on goal percentages for each player on the team.
	 */
	public void setPercentages(double[] percentages)
	{
		this.percentages = copyPercentages(percentages);
	}

	/**
	 * Returns a new array containing the values of the
	 * percentages array sorted in descending order.
	 *
	 * @return A new array containing the values of the percentages array sorted in descending order.
	 */
	public double[] getSortedPercentages()
	{
		double[] sort = copyPercentages(percentages);

		// For loop to sort the elements of the array in descending order.
		for ( int i = 0; i < percentages.length; i++ )
		{
			for ( int j = i + 1; j < percentages.length; j++ )
			{
				double temp = 0;

				if ( sort[i] < sort[j] )
				{
					temp = sort[i];
					sort[i] = sort[j];
					sort[j] = temp;
				}
			}
		}

		return sort;
	}

	/**
	 * Returns the value of the player with the lowest
	 * percentage in the specified array.
	 *
	 * @param percentages The percentages for each player on a team.
	 * @return The value of the player with the lowest percentage.
	 */
	public static double getLowestPercentage(double[] percentages)
	{
		double lowestPercent = percentages[0];

		// For loop to determine the lowest percentage.
		for ( int i = 1; i < percentages.length; i++ )
		{
			if ( percentages[i] < lowestPercent )
			{
				lowestPercent = percentages[i];
			}
		}

		return lowestPercent;
	}

	/**
	 * Returns the mean average of percentages for the top players on the team.
	 *
	 * @return The average of percentages for the top players.
	 */
	public double getAverageOfTopPlayers()
	{
		double[] sort = getSortedPercentages();
		double average = 0;
		double sum = 0;

		// For loop to calculate the average based on values within the first 5 elements.
		for ( int i = 0; i < sort.length; i++ )
		{
			if ( i < 5 )
			{
				sum += sort[i];
				average = sum / ( i + 1 );
			}
		}

		return average;
	}

	/**
	 * Returns a String representation of the weather forecast.
	 *
	 * @return A String representation of the weather forecast.
	 */
	public String toString()
	{
		DecimalFormat decimals = new DecimalFormat("0.000000");
		String output = "--------------------\n" +
			"Player        SOG%\n" +
			"--------------------\n";

		// For loop to add each element with formatting to the existing output.
		for ( int i = 0; i < percentages.length; i++ )
		{
			output += i + 1 + "\t      ";
			output += decimals.format(percentages[i]) + "\n";
		}

		return output;
	}
}