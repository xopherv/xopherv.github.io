/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: November 27, 2021
 * Updated: November 30, 2021
 */
import java.util.Arrays;
import java.text.DecimalFormat;
/**
 * A program to test the TeamShotOnGoalPercentages class.
 *
 * @author CJ Vergel
 * @version 1.1
 */
public class TeamShotOnGoalPercentagesTests
{
	public static void main(String[] args)
	{
		System.out.println("TeamShotOnGoalPercentages(int)");

		System.out.println("Test #1 - Initialize percentages array without data.");
		constructor1_initializeArrayWithoutData();

		System.out.println("\nTeamShotOnGoalPercentages(double[])");
		System.out.println("Test #1 - Initialize percentages array with data.");
		constructor2_initializeArrayWithData();

		System.out.println("\ngetPercentages()");
		System.out.println("Test #1 - Returns a copy of the array used to initialize the object.");
		getPercentages_returnsCopyOfArray();

		System.out.println("\nsetPercentages()");
		System.out.println("Test #1 - Updates the state of the percentages.");
		setPercentages_updatesStateOfPercentages();

		System.out.println("\ngetSortedPercentages()");
		System.out.println("Test #1 - Returns a copy of the percentages array sorted in descending order.");
		getSortedPercentages_returnsCopyOfPercentagesArrayInDescendingOrder();

		System.out.println("\ngetLowestPercentage()");
		System.out.println("Test #1 - Returns the correct lowest percentage value.");
		getLowestPercentage_returnsLowestPercentage();

		System.out.println("\ngetAverageOfTopPlayers()");
		System.out.println("Test #1 - Returns the correct average of the top five players where the number of players is greater than 5.");
		getAverageOfTopPlayers_returnsAverageOfTopFiveForNumberOfPlayersOverFive();

		System.out.println("\nTest #2 - Returns the correct average of the top five players where the number of players is less than 5.");
		getAverageOfTopPlayers_returnsAverageOfTopFiveForNumberOfPlayersUnderFive();

		System.out.println("\ntoString()");
		System.out.println("Test #1 - Returns the correct String representation.");
		toString_returnsStringRepresentation();
	}

	/*
	 * Constructor1 - TeamShotOnGoalPercentages(int)
	 */

	public static void constructor1_initializeArrayWithoutData()
	{
		// Setup test data
		int numberOfPlayers = 4;

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(numberOfPlayers);

		// Confirm
		String expected = "[0.0, 0.0, 0.0, 0.0]";
		double[] actual = target.getPercentages();

		System.out.println("Expected: " + expected + "\nActual:   "
			+ Arrays.toString(actual));
	}

	/*
	 * Constructor2 - TeamShotOnGoalPercentages(double[])
	 */

	public static void constructor2_initializeArrayWithData()
	{
		// Setup test data
		double[] percentages = {0.69, 0.42, 0.99, 0.77};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		String expected = "[0.69, 0.42, 0.99, 0.77]";
		double[] actual = target.getPercentages();

		System.out.println("Expected: " + expected + "\nActual:   "
			+ Arrays.toString(actual));
	}

	public static void getPercentages_returnsCopyOfArray()
	{
		// Setup test data
		double[] percentages = {0.69, 0.42, 0.99, 0.77};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		int original = percentages.hashCode();
		double[] clone = target.getPercentages();

		System.out.println("Original Hash: " + original + "\nClone Hash:   "
			+ clone.hashCode());
	}

	public static void setPercentages_updatesStateOfPercentages()
	{
		// Setup test data
		double[] percentages = {0.69, 0.42, 0.99, 0.77};

		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		double[] newPercentages = {0.33, 0.11, 0.96, 0.76, 0.26};

		// Act
		target.setPercentages(newPercentages);

		// Confirm
		String expected = "[0.33, 0.11, 0.96, 0.76, 0.26]";
		double[] actual = target.getPercentages();

		System.out.println("Expected: " + expected + "\nActual:   "
			+ Arrays.toString(actual));
	}

	public static void getSortedPercentages_returnsCopyOfPercentagesArrayInDescendingOrder()
	{
		// Setup test data
		double[] percentages = {0.33, 0.11, 0.96, 0.76, 0.26};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		String expected = "[0.96, 0.76, 0.33, 0.26, 0.11]";
		double[] actual = target.getSortedPercentages();

		System.out.println("Expected: " + expected + "\nActual:   "
			+ Arrays.toString(actual));
	}

	public static void getLowestPercentage_returnsLowestPercentage()
	{
		// Setup test data
		double[] percentages = {0.33, 0.11, 0.96, 0.76, 0.26};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		String expected = "0.11";
		double actual = target.getLowestPercentage(percentages);

		System.out.println("Expected: " + expected + "\nActual:   "
			+ actual);
	}

	public static void getAverageOfTopPlayers_returnsAverageOfTopFiveForNumberOfPlayersOverFive()
	{
		// Setup test data
		double[] percentages = {0.33, 0.11, 0.96, 0.76, 0.26, 0.68};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		String expected = "0.598";
		double actual = target.getAverageOfTopPlayers();

		System.out.printf("Expected: %s\nActual:   %4.3f%n", expected, actual);
	}

	public static void getAverageOfTopPlayers_returnsAverageOfTopFiveForNumberOfPlayersUnderFive()
	{
		// Setup test data
		double[] percentages = {0.33, 0.11, 0.96, 0.76};

		// Act
		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Confirm
		String expected = "0.540";
		double actual = target.getAverageOfTopPlayers();

		System.out.printf("Expected: %s\nActual:   %4.3f%n", expected, actual);
	}

	public static void toString_returnsStringRepresentation()
	{
		// Setup test data
		double[] percentages = {0.41, 0.33, 0.98, 0.77, 0.1};

		TeamShotOnGoalPercentages target
			= new TeamShotOnGoalPercentages(percentages);

		// Act
		String actual = target.toString();

		// Confirm
		String expected = "--------------------\n" + "Player        SOG%\n" +
			"--------------------\n" + "1             0.410000\n" +
			"2             0.330000\n" + "3             0.980000\n" +
			"4             0.770000\n" + "5             0.100000\n";

		System.out.printf("Expected:%n%s%nActual:%n%s%n", expected, actual);
	}
}
