﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-01-22
 * Updated: 2022-03-04
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Vergel.CJ.Business
{
    /// <summary>
    /// Determines a quote for the sale of a vehicle.
    /// </summary>
    public class SalesQuote
    {
        private decimal vehicleSalePrice;
        private decimal tradeInAmount;
        private decimal salesTaxRate;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;

        /// <summary>
        /// Occurs when the price of the vehicle being quoted on changes.
        /// </summary>
        public event EventHandler VehiclePriceChanged;

        /// <summary>
        /// Occurs when the amount for the trade in vehicle changes.
        /// </summary>
        public event EventHandler TradeInAmountChanged;

        /// <summary>
        /// Occurs when the chosen accessories change.
        /// </summary>
        public event EventHandler AccessoriesChosenChanged;

        /// <summary>
        /// Occurs when the chosen exterior finish changes.
        /// </summary>
        public event EventHandler ExteriorFinishChosenChanged;

        /// <summary>
        /// Gets and sets the sale price of the vehicle.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Occurs when the property is set to less than or equal to 0.
        /// </exception>
        public decimal VehicleSalePrice
        {
            get
            {
                return this.vehicleSalePrice;
            }

            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("value",
                        "The value cannot be less than or equal to 0.");
                }

                if (this.vehicleSalePrice != value)
                {
                    this.vehicleSalePrice = value;
                    OnVehiclePriceChanged();
                }
            }
        }

        /// <summary>
        /// Gets and sets the trade in amount.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Occurs when the property is set to less than 0.
        /// </exception>
        public decimal TradeInAmount
        {
            get
            {
                return this.tradeInAmount;
            }
            
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value", 
                        "The value cannot be less than 0.");
                }

                if (this.tradeInAmount != value)
                {
                    this.tradeInAmount = value;
                    OnTradeInAmountChanged();
                }
            }
        }

        /// <summary>
        /// Gets and sets the accessories that were chosen.
        /// </summary>
        /// <exception cref="InvalidEnumArgumentException">
        /// Occurs when the property is set to an invalid value.
        /// </exception>
        public Accessories AccessoriesChosen
        {
            get
            {
                return this.accessoriesChosen;
            }

            set
            {
                if (!Enum.IsDefined(typeof(Accessories), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value.");
                }

                if (this.accessoriesChosen != value)
                {
                    this.accessoriesChosen = value;
                    OnAccessoriesChosenChanged();
                }
            }
        }

        /// <summary>
        /// Gets and sets the exterior finish that was chosen.
        /// </summary>
        /// <exception cref="InvalidEnumArgumentException">
        /// Occurs when the property is set to an invalid value.
        /// </exception>
        public ExteriorFinish ExteriorFinishChosen
        {
            get
            {
                return this.exteriorFinishChosen;
            }

            set
            {
                if (!Enum.IsDefined(typeof(ExteriorFinish), value))
                {
                    throw new InvalidEnumArgumentException("The value is an invalid enumeration value.");
                }

                if (this.exteriorFinishChosen != value)
                {
                    this.exteriorFinishChosen = value;
                    OnExteriorFinishChosenChanged();
                }
            }
        }

        /// <summary>
        /// Gets the cost of the accessories chosen.
        /// </summary>
        public decimal AccessoryCost
        {
            get 
            {
                const decimal StereoSystemCost = 505.05M;
                const decimal LeatherInteriorCost = 1010.10M;
                const decimal ComputerNavigationCost = 1515.15M;
                decimal accessoryCost = 0;

                if (accessoriesChosen == Accessories.StereoSystem)
                {
                    accessoryCost = StereoSystemCost;
                }

                else if (accessoriesChosen == Accessories.LeatherInterior)
                {
                    accessoryCost = LeatherInteriorCost;
                }

                else if (accessoriesChosen == Accessories.StereoAndLeather)
                {
                    accessoryCost = StereoSystemCost + LeatherInteriorCost;
                }

                else if (accessoriesChosen == Accessories.ComputerNavigation)
                {
                    accessoryCost = ComputerNavigationCost;
                }

                else if (accessoriesChosen == Accessories.StereoAndNavigation)
                {
                    accessoryCost = StereoSystemCost + ComputerNavigationCost;
                }

                else if (accessoriesChosen == Accessories.LeatherAndNavigation)
                {
                    accessoryCost = LeatherInteriorCost + ComputerNavigationCost;
                }

                else if (accessoriesChosen == Accessories.All)
                {
                    accessoryCost = StereoSystemCost + LeatherInteriorCost + ComputerNavigationCost;
                }

                return accessoryCost;
            }
        }

        /// <summary>
        /// Gets the cost of the exterior finish chosen.
        /// </summary>
        public decimal FinishCost
        {
            get
            {
                const decimal StandardCost = 202.02M;
                const decimal PearlizedCost = 404.04M;
                const decimal CustomCost = 606.06M;
                decimal exteriorFinishCost = 0;

                if (exteriorFinishChosen == ExteriorFinish.Standard)
                {
                    exteriorFinishCost = StandardCost;
                }

                else if (exteriorFinishChosen == ExteriorFinish.Pearlized)
                {
                    exteriorFinishCost = PearlizedCost;
                }

                else if (exteriorFinishChosen == ExteriorFinish.Custom)
                {
                    exteriorFinishCost = CustomCost;
                }

                return exteriorFinishCost;
            }
        }

        /// <summary>
        /// Gets the sum of the cost of the chosen accessories and exterior finish
        /// (rounded to two decimal places).
        /// </summary>
        public decimal TotalOptions
        {
            get
            {
                return Math.Round(this.FinishCost + this.AccessoryCost, 2);
            }
        }

        /// <summary>
        /// Gets the sum of the vehicle's sale price and the Accessory and Finish cost
        /// (rounded to two decimal places).
        /// </summary>
        public decimal SubTotal
        {
            get
            {
                return Math.Round(this.vehicleSalePrice + TotalOptions, 2);
            }
        }

        /// <summary>
        /// Gets the amount of tax to charge based on the subtotal
        /// (rounded to two decimal places).
        /// </summary>
        public decimal SalesTax
        {
            get
            {
                return Math.Round(SubTotal * this.salesTaxRate, 2);
            }
        }


        /// <summary>
        /// Gets the sum of the subtotal and taxes.
        /// </summary>
        public decimal Total
        {
            get
            {
                return SubTotal + SalesTax;
            }
        }

        /// <summary>
        /// Gets the result of subtracting the trade-in amount from the total
        /// (rounded to two decimal places).
        /// </summary>
        public decimal AmountDue
        {
            get
            {
                return Math.Round(Total - this.tradeInAmount, 2);
            }
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, 
        /// trade-in value, sales tax rate, accessories chosen, and 
        /// exterior finish chosen.
        /// </summary>
        /// <param name="vehicleSalePrice">
        /// The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">
        /// The amount offered to the customer for the trade-in of their vehicle.</param>
        /// <param name="salesTaxRate">
        /// The tax rate applied to the sale of the vehicle.</param>
        /// <param name="accessoriesChosen">
        /// The chosen accessories.</param>
        /// <param name="exteriorFinishChosen">
        /// The chosen exterior finish.</param>
        /// <exception cref="ArgumentOutOfRangeException">
        /// Occurs when the vehicle sale price is less than or equal to 0,
        /// the trade-in amount or sales tax rate is less than 0, or 
        /// the sales tax rate is greater than 1.
        /// </exception>
        /// <exception cref="InvalidEnumArgumentException">
        /// Occurs when the accessories chosen or exterior finish chosen 
        /// is an invalid argument.
        /// </exception>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount,
            decimal salesTaxRate, Accessories accessoriesChosen, 
            ExteriorFinish exteriorFinishChosen)
        {
            if (vehicleSalePrice <= 0)
            {
                throw new ArgumentOutOfRangeException("vehicleSalePrice", 
                    "The argument cannot be less than or equal to 0.");
            }

            if (tradeInAmount < 0)
            {
                throw new ArgumentOutOfRangeException("tradeInAmount",
                    "The argument cannot be less than 0.");
            }

            if (salesTaxRate < 0)
            {
                throw new ArgumentOutOfRangeException("salesTaxRate",
                    "The argument cannot be less than 0.");
            }

            if (salesTaxRate > 1)
            {
                throw new ArgumentOutOfRangeException("salesTaxRate",
                    "The argument cannot be greater than 1.");
            }

            if (!Enum.IsDefined(typeof(Accessories), accessoriesChosen))
            {
                throw new InvalidEnumArgumentException("The argument is an invalid enumeration value.");
            }

            if (!Enum.IsDefined(typeof(ExteriorFinish), exteriorFinishChosen))
            {
                throw new InvalidEnumArgumentException("The argument is an invalid enumeration value.");
            }

            this.vehicleSalePrice = vehicleSalePrice;
            this.tradeInAmount = tradeInAmount;
            this.salesTaxRate = salesTaxRate;
            AccessoriesChosen = accessoriesChosen;
            ExteriorFinishChosen = exteriorFinishChosen;
        }

        /// <summary>
        /// Initializes an instance of SalesQuote with a vehicle price, 
        /// trade-in value, sales tax rate, accessories chosen to none, and 
        /// exterior finish to none.
        /// </summary>
        /// <param name="vehicleSalePrice">
        /// The selling price of the vehicle being sold.</param>
        /// <param name="tradeInAmount">
        /// The amount offered to the customer for the trade-in of their vehicle.</param>
        /// <param name="salesTaxRate">
        /// The tax rate applied to the sale of the vehicle.</param>
        public SalesQuote(decimal vehicleSalePrice, decimal tradeInAmount, decimal salesTaxRate) 
            : this(vehicleSalePrice, tradeInAmount, salesTaxRate, Accessories.None, ExteriorFinish.None)
        {

        }

        /// <summary>
        /// Raises the VehiclePriceChanged event.
        /// </summary>
        protected virtual void OnVehiclePriceChanged()
        {
            if (VehiclePriceChanged != null)
            {
                VehiclePriceChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the TradeInAmountChanged event.
        /// </summary>
        protected virtual void OnTradeInAmountChanged()
        {
            if (TradeInAmountChanged != null)
            {
                TradeInAmountChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the AccessoriesChosenChanged event.
        /// </summary>
        protected virtual void OnAccessoriesChosenChanged()
        {
            if (AccessoriesChosenChanged != null)
            {
                AccessoriesChosenChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// Raises the ExteriorFinishChosenChanged event.
        /// </summary>
        protected virtual void OnExteriorFinishChosenChanged()
        {
            if (ExteriorFinishChosenChanged != null)
            {
                ExteriorFinishChosenChanged(this, new EventArgs());
            }
        }

    }
}