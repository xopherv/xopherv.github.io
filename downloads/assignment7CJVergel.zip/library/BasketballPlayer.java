/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: December 11, 2021
 */

/**
 * Represents a basketball player.
 *
 * @author CJ Vergel
 * @version 1.0
 */
public class BasketballPlayer extends Player
{
	// Declaring variables.
	private int freeThrows;
	private int fieldGoals;
	private int threePointers;

	/**
	 * Initializes a new instance of the BasketballPlayer class with the specified
	 * name and number with free throws, field goals, and three pointers set to 0.
	 *
	 * @param name The player's name.
	 * @param number The player's number.
	 */
	public BasketballPlayer(String name, int number)
	{
		super(name, number);

		freeThrows = 0;
		fieldGoals = 0;
		threePointers = 0;
	}

	/**
	 * Returns the number of free throws made by the basketball player.
	 *
	 * @return freeThrows The number of free throws made by the basketball player.
	 */
	public int getFreeThrows()
	{
		return this.freeThrows;
	}

	/**
	 * Sets the number of free throws made by the basketball player.
	 *
	 * @param freeThrows The number of free throws made by the basketball player.
	 */
	public void setFreeThrows(int freeThrows)
	{
		this.freeThrows = freeThrows;
	}

	/**
	 * Returns the number of field goals made by the basketball player.
	 *
	 * @return fieldGoals The number of field goals made by the basketball player.
	 */
	public int getFieldGoals()
	{
		return this.fieldGoals;
	}

	/**
	 * Sets the number of field goals made by the basketball player.
	 *
	 * @param fieldGoals The number of field goals made by the basketball player.
	 */
	public void setFieldGoals(int fieldGoals)
	{
		this.fieldGoals = fieldGoals;
	}

	/**
	 * Returns the number of three pointers made by the basketball player.
	 *
	 * @return threePointers The number of three pointers made by the basketball player.
	 */
	public int getThreePointers()
	{
		return this.threePointers;
	}

	/**
	 * Sets the number of three pointers made by the basketball player.
	 *
	 * @param threePointers The number of three pointers made by the basketball player.
	 */
	public void setThreePointers(int threePointers)
	{
		this.threePointers = threePointers;
	}

	/**
	 * Returns the number of points accumulated by the basketball player.
	 *
	 * @return points The number of points accumulated by the basketball player.
	 */
	public int getPoints()
	{
		int points;

		points = this.freeThrows + ( this.fieldGoals * 2 ) +
				( this.threePointers * 3 );

		return points;
	}

	/**
	 * Returns the String representation of the player.
	 *
	 * @return The String representation of the player.
	 */
	public String toString()
	{
		return String.format("Basketball Player: %s [%d], Points: %d", getName(), getNumber(), getPoints());
	}
}