﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-03-15
 * Updated: 2022-04-22
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ACE.BIT.ADEV;
using Vergel.CJ.Business;
using System.Data.OleDb;

namespace Vergel.CJ.RRCAGApp
{
    /// <summary>
    /// A form class that displays
    /// vehicle data in a data grid view.
    /// </summary>
    public partial class VehicleDataForm : ACE.BIT.ADEV.Forms.VehicleDataForm
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private BindingSource bindingSource;

        /// <summary>
        /// Initializes an instance of the VehicleDataForm class.
        /// </summary>
        public VehicleDataForm()
        {
            InitializeComponent();

            InitializeVehicleDataForm();

            this.bindingSource = new BindingSource();
            this.Load += VehicleDataForm_Load;
            this.dgvVehicles.CurrentCellChanged += DgvVehicles_CurrentCellChanged;
            this.dgvVehicles.CellValueChanged += DgvVehicles_CellValueChanged;
            this.mnuFileSave.Click += MnuFileSave_Click;
            this.mnuFileClose.Click += MnuFileClose_Click;
            this.mnuEditDelete.Click += MnuEditDelete_Click;
            this.FormClosing += VehicleDataForm_FormClosing;
        }

        /// <summary>
        /// Handles the Load event of the Vehicle Data Form.
        /// </summary>
        private void VehicleDataForm_Load(object sender, EventArgs e)
        {
            try
            {
                RetrieveDataFromTheDatabase();

                BindControls();
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to load vehicle data", "Data Load Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.adapter.RowUpdated += Adapter_RowUpdated;
        }

        /// <summary>
        /// Handles the Row updated event of the adapter.
        /// </summary>
        private void Adapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType == StatementType.Insert)
            {
                OleDbCommand cmd = new OleDbCommand("SELECT @@IDENTITY", connection);

                e.Row["ID"] = (int)cmd.ExecuteScalar();
                e.Row["SoldBy"] = 0;
            }
        }

        /// <summary>
        /// Handles the form closing event of the Vehicle Data Form.
        /// </summary>
        private void VehicleDataForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (ActiveForm.ActiveMdiChild.Text.Equals("* Vehicle Data"))
                {
                    var result = MessageBox.Show("Do you wish to save changes?", "Save",
                        MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button3);

                    if (result == DialogResult.Yes)
                    {
                        this.dgvVehicles.EndEdit();

                        this.bindingSource.EndEdit();

                        adapter.Update(dataset, "VehicleStock");
                    }
                    else if (result == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
            catch (Exception)
            {
                var result = MessageBox.Show("An error occurred while saving. Do you still wish to close?",
                    "Save Error", MessageBoxButtons.YesNo, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2);

                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// Handles the Cell Value Changed event 
        /// for the Vehicles DataGridView.
        /// </summary>
        private void DgvVehicles_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            ActiveForm.ActiveMdiChild.Text = "* Vehicle Data";
            this.mnuFileSave.Enabled = true;
        }

        /// <summary>
        /// Handles the Current Cell Changed event 
        /// for the Vehicles DataGridView.
        /// </summary>
        private void DgvVehicles_CurrentCellChanged(object sender, EventArgs e)
        {
            if (this.dgvVehicles.SelectedRows.Count > 0 && !this.dgvVehicles.CurrentRow.IsNewRow)
            {
                this.mnuEditDelete.Enabled = true;
            }
            else
            {
                this.mnuEditDelete.Enabled = false;
            }
        }

        /// <summary>
        /// Handles the Click event of the Delete menu item.
        /// </summary>
        private void MnuEditDelete_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show($"Are you sure you want to permanently delete stock item {dgvVehicles.CurrentRow.Cells[1].Value}?", "Delete Stock Item",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            try
            {
                if (result == DialogResult.Yes)
                {
                    ActiveForm.ActiveMdiChild.Text = "Vehicle Data";
                    this.mnuEditDelete.Enabled = false;
                    this.dgvVehicles.Rows.RemoveAt(
                        this.dgvVehicles.SelectedRows[0].Index);
                    this.dgvVehicles.EndEdit();
                    this.bindingSource.EndEdit();
                }
            }
            catch(Exception)
            {
                MessageBox.Show("An error occurred while deleting the selected vehicle.", "Deletion Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Handles the Click event of the Close menu item.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Click event of the Save menu item.
        /// </summary>
        private void MnuFileSave_Click(object sender, EventArgs e)
        {
            try
            { 
                this.dgvVehicles.EndEdit();

                this.bindingSource.EndEdit();

                adapter.Update(dataset, "VehicleStock");

                ActiveForm.ActiveMdiChild.Text = "Vehicle Data";

                this.mnuFileSave.Enabled = false;
            }
            catch(Exception)
            {
                MessageBox.Show("An error occurred while saving the changes to the vehicle data.",
                    "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Queries the database and populates the dataset.
        /// </summary>
        private void RetrieveDataFromTheDatabase()
        {
            connection = new OleDbConnection();

            connection.ConnectionString = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = AMDatabase.mdb";

            connection.Open();

            OleDbCommand selectCommand = new OleDbCommand();

            selectCommand.CommandText = "SELECT * FROM VehicleStock";

            selectCommand.Connection = connection;

            adapter = new OleDbDataAdapter();

            adapter.SelectCommand = selectCommand;

            dataset = new DataSet();

            adapter.Fill(dataset, "VehicleStock");

            OleDbCommandBuilder commandBuilder = new OleDbCommandBuilder();

            commandBuilder.DataAdapter = adapter;

            commandBuilder.ConflictOption = ConflictOption.OverwriteChanges;

            adapter.InsertCommand = commandBuilder.GetInsertCommand(true);
            adapter.DeleteCommand = commandBuilder.GetDeleteCommand(true);
            adapter.UpdateCommand = commandBuilder.GetUpdateCommand(true);
        }

        /// <summary>
        /// Binds the controls on the form.
        /// </summary>
        private void BindControls()
        {
            bindingSource.DataSource = dataset.Tables[0];

            this.dgvVehicles.DataSource = bindingSource;

            this.dgvVehicles.Columns["ID"].Visible = false;
            this.dgvVehicles.Columns["SoldBy"].Visible = false;
        }

        /// <summary>
        /// Initializes the Vehicle Data Form
        /// in its initial state.
        /// </summary>
        private void InitializeVehicleDataForm()
        {
            mnuFileSave.Enabled = false;
            mnuEditDelete.Enabled = false;

            dgvVehicles.AllowUserToDeleteRows = false;
            dgvVehicles.AllowUserToResizeRows = false;
            dgvVehicles.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvVehicles.MultiSelect = false;
        }
    }
}
