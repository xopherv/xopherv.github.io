﻿/*
 * Name: CJ Vergel
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-03-15
 * Updated: 2022-04-10
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ACE.BIT.ADEV;
using Vergel.CJ.Business;
using ACE.BIT.ADEV.CarWash;
using System.IO;
using ACE.BIT.ADEV.Forms;

namespace Vergel.CJ.RRCAGApp
{
    /// <summary>
    /// A form class that has functionality to
    /// create a Car Wash Invoice from provided 
    /// values and chosen accessories.
    /// </summary>
    public partial class CarWashForm : ACE.BIT.ADEV.Forms.CarWashForm
    {
        private BindingList<Package> packages;
        private BindingList<CarWashItem> fragrances;
        private List<String> interiorServices;
        private List<String> exteriorServices;
        private BindingSource packageBindingSource;
        private BindingSource fragranceBindingSource;
        private BindingSource interiorBindingSource;
        private BindingSource exteriorBindingSource;
        private BindingSource totalsBindingSource;
        private CarWashInvoiceForm invoiceForm;

        /// <summary>
        /// Initializes an instance of the CarWashForm class.
        /// </summary>
        public CarWashForm()
        {
            InitializeComponent();

            mnuToolsGenerateInvoice.Enabled = false;

            LoadFragrances();

            this.packages = new BindingList<Package>();

            this.packages.Add(new Package("Standard", 7.5m, interiorServices, exteriorServices));
            this.packages.Add(new Package("Deluxe", 15m, interiorServices, exteriorServices));
            this.packages.Add(new Package("Executive", 35m, interiorServices, exteriorServices));
            this.packages.Add(new Package("Luxury", 55m, interiorServices, exteriorServices));

            this.interiorServices = new List<String>();
            this.exteriorServices = new List<String>();

            this.packageBindingSource = new BindingSource();
            this.packageBindingSource.DataSource = this.packages;

            this.fragranceBindingSource = new BindingSource();
            this.fragranceBindingSource.DataSource = this.fragrances;

            this.totalsBindingSource = new BindingSource();
            this.totalsBindingSource.DataSource = typeof(CarWashInvoice);

            BindControls();
            
            invoiceForm = new CarWashInvoiceForm(this.totalsBindingSource);

            this.cboPackage.SelectedIndexChanged += CurrentValueChanged;
            this.fragranceBindingSource.CurrentChanged += CurrentValueChanged;
            this.mnuFileClose.Click += MnuFileClose_Click;
            this.mnuToolsGenerateInvoice.Click += MnuToolsGenerateInvoice_Click;
            this.invoiceForm.FormClosed += InvoiceForm_FormClosed;
            
        }

        /// <summary>
        /// Handles the Form Closed event of the Invoice Form.
        /// </summary>
        private void InvoiceForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ResetForm();
        }

        /// <summary>
        /// Handles the Click event of the Generate Invoice menu item.
        /// </summary>
        private void MnuToolsGenerateInvoice_Click(object sender, EventArgs e)
        {
            invoiceForm.ShowDialog();
        }

        /// <summary>
        /// Handles the Click event of the Close menu item.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Current Value Changed event 
        /// for the combo box values.
        /// </summary>
        private void CurrentValueChanged(object sender, EventArgs e)
        {
            UpdateInteriorListBox();
            UpdateExteriorListBox();
            UpdateTotals();
            mnuToolsGenerateInvoice.Enabled = true;
        }

        /// <summary>
        /// Binds the controls on the form.
        /// </summary>
        private void BindControls()
        {
            this.cboPackage.DataSource = this.packageBindingSource;
            this.cboPackage.DisplayMember = "Description";
            this.cboPackage.ValueMember = "Price";
            this.cboPackage.SelectedIndex = -1;

            this.cboFragrance.DataSource = this.fragranceBindingSource;
            this.cboFragrance.DisplayMember = "Description";
            this.cboFragrance.ValueMember = "Price";
            this.cboFragrance.SelectedIndex = 4;

            Binding subtotalBind = new Binding("Text", totalsBindingSource, "Subtotal");
            subtotalBind.FormattingEnabled = true;
            subtotalBind.FormatString = "C";
            this.lblSubtotal.DataBindings.Add(subtotalBind);

            Binding gstBind = new Binding("Text", totalsBindingSource, "GoodsAndServicesTaxCharged");
            this.lblGoodsAndServicesTax.DataBindings.Add(gstBind);

            Binding pstBind = new Binding("Text", totalsBindingSource, "ProvincialSalesTaxCharged");
            this.lblProvincialSalesTax.DataBindings.Add(pstBind);

            Binding totalBind = new Binding("Text", totalsBindingSource, "Total");
            totalBind.FormattingEnabled = true;
            totalBind.FormatString = "C";
            this.lblTotal.DataBindings.Add(totalBind);
        }

        /// <summary>
        /// Resets the form to its initial state.
        /// </summary>
        private void ResetForm()
        {
            this.cboFragrance.SelectedIndex = 4;
            this.cboPackage.SelectedIndex = -1;
            this.interiorBindingSource.Clear();
            this.exteriorBindingSource.Clear();
            this.lblSubtotal.Text = null;
            this.lblProvincialSalesTax.Text = null;
            this.lblGoodsAndServicesTax.Text = null;
            this.lblTotal.Text = null;
        }

        /// <summary>
        /// Loads the fragrances file to be used by the form.
        /// </summary>
        private void LoadFragrances()
        {
            FileStream fileStream = new FileStream("fragrances.txt", FileMode.Open, FileAccess.Read);
            StreamReader fileReader = new StreamReader(fileStream);
            this.fragrances = new BindingList<CarWashItem>();

            try
            {
                CarWashItem fragrance;

                while (fileReader.Peek() != -1)
                {
                    string record = fileReader.ReadLine();

                    char[] delimiters = { ',' };

                    string[] fields = record.Split(delimiters);

                    string fragranceName = fields[0];

                    decimal fragrancePrice = Decimal.Parse(fields[1]);

                    fragrance = new CarWashItem();
                    fragrance.Description = fragranceName;
                    fragrance.Price = fragrancePrice;

                    fragrances.Add(fragrance);
                }
            }
            catch (IOException)
            {
                MessageBox.Show("An error occurred while reading the data file.",
                "Data File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            CarWashItem pine = new CarWashItem();
            pine.Description = "Pine";
            pine.Price = 0.00m;
            fragrances.Insert(4, pine);
            fileReader.Close();
        }

        /// <summary>
        /// Updates the Interior List Box when the selected
        /// index for the Packages combo box is changed.
        /// </summary>
        private void UpdateInteriorListBox()
        {
            if (this.cboPackage.SelectedIndex == 0)
            {
                this.interiorServices.Clear();
                this.interiorServices.Add("Fragrance - " + this.fragranceBindingSource.Current);
            }
            else if (this.cboPackage.SelectedIndex == 1)
            {
                this.interiorServices.Clear();
                this.interiorServices.Add("Fragrance - " + this.fragranceBindingSource.Current);
                this.interiorServices.Add("Shampoo Carpets");
            }
            else if (this.cboPackage.SelectedIndex == 2)
            {
                this.interiorServices.Clear();
                this.interiorServices.Add("Fragrance - " + this.fragranceBindingSource.Current);
                this.interiorServices.Add("Shampoo Carpets");
                this.interiorServices.Add("Shampoo Upholstery");
            }
            else if (this.cboPackage.SelectedIndex == 3)
            {
                this.interiorServices.Clear();
                this.interiorServices.Add("Fragrance - " + this.fragranceBindingSource.Current);
                this.interiorServices.Add("Shampoo Carpets");
                this.interiorServices.Add("Shampoo Upholstery");
                this.interiorServices.Add("Interior Protection Coat");
            }

            interiorBindingSource = new BindingSource();

            interiorBindingSource.DataSource = interiorServices;

            this.lstInterior.DataSource = interiorBindingSource;
        }

        /// <summary>
        /// Updates the Exterior List Box when the selected
        /// index for the Packages combo box is changed.
        /// </summary>
        private void UpdateExteriorListBox()
        {
            if (this.cboPackage.SelectedIndex == 0)
            {
                this.exteriorServices.Clear();
                this.exteriorServices.Add("Hand Wash");
            }
            else if (this.cboPackage.SelectedIndex == 1)
            {
                this.exteriorServices.Clear();
                this.exteriorServices.Add("Hand Wash");
                this.exteriorServices.Add("Hand Wax");
            }
            else if (this.cboPackage.SelectedIndex == 2)
            {
                this.exteriorServices.Clear();
                this.exteriorServices.Add("Hand Wash");
                this.exteriorServices.Add("Hand Wax");
                this.exteriorServices.Add("Wheel Polish");
            }
            else if (this.cboPackage.SelectedIndex == 3)
            {
                this.exteriorServices.Clear();
                this.exteriorServices.Add("Hand Wash");
                this.exteriorServices.Add("Hand Wax");
                this.exteriorServices.Add("Wheel Polish");
                this.exteriorServices.Add("Detail Engine Compartment");
            }

            exteriorBindingSource = new BindingSource();

            exteriorBindingSource.DataSource = exteriorServices;

            this.lstExterior.DataSource = exteriorBindingSource;
        }

        /// <summary>
        /// Updates the totals in the display labels.
        /// </summary>
        private void UpdateTotals()
        {
            if (cboPackage.SelectedIndex != -1)
            { 
                CarWashInvoice carWashInvoice = new CarWashInvoice(0.07m, 0.05m,
                    (decimal)this.cboPackage.SelectedValue, (decimal)this.cboFragrance.SelectedValue);

                this.totalsBindingSource.DataSource = carWashInvoice;
            }
        }
    } 
}
