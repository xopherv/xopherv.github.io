/*
 * Name: Christopher Vergel
 * Program: Business Information Technology
 * Course: ADEV-1008 Programming 1
 * Created: December 11, 2021
 */

/**
 * A program to test the HockeyPlayer class.
 *
 * @author CJ Vergel
 * @version 1.0
 */
public class HockeyPlayerTests
{
	public static void main(String[] args)
	{
		System.out.println("\nHockeyPlayer(String, int)");

		System.out.println("Test #1 - Initialize the name.");
		constructor1_initializeName();

		System.out.println("\nTest #2 - Initialize the number.");
		constructor1_initializeNumber();

		System.out.println("\nTest #3 - Initialize the goals.");
		constructor1_initializeGoals();

		System.out.println("\nTest #4 - Initialize the assists.");
		constructor1_initializeAssists();

		System.out.println("\nHockeyPlayer(String, int, int, int)");

		System.out.println("Test #1 - Initialize the name.");
		constructor2_initializeName();

		System.out.println("\nTest #2 - Initialize the number.");
		constructor2_initializeNumber();

		System.out.println("\nTest #3 - Initialize the goals.");
		constructor2_initializeGoals();

		System.out.println("\nTest #4 - Initialize the assists.");
		constructor2_initializeAssists();

		System.out.println("\nsetName(String)");

		System.out.println("Test #1 - Updates the state of name.");
		setName_updatesStateOfName();

		System.out.println("\nsetNumber(int)");

		System.out.println("Test #1 - Updates the state of number.");
		setNumber_updatesStateOfNumber();

		System.out.println("\nsetGoals(int)");

		System.out.println("Test #1 - Updates the state of goals.");
		setGoals_updatesStateOfGoals();

		System.out.println("\nsetAssists(int)");

		System.out.println("Test #1 - Updates the state of assists.");
		setAssists_updatesStateOfAssists();

		System.out.println("\ngetPoints(int)");

		System.out.println("Test #1 - Returns the correct number of points.");
		getPoints_returnsCorrectNumberOfPoints();

		System.out.println("\ntoString()");

		System.out.println("Test #1 - Returns the correct String representation.");
		toString_returnsStringRepresentation();
	}

	/*
	 * Constructor1 - HockeyPlayer(String, int)
	 */

	public static void constructor1_initializeName()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number);

		// Confirm
		String expected = "Blake";
		String actual = target.getName();

		System.out.printf("Expected: %s\nActual: %s\n", expected, actual);
	}

	public static void constructor1_initializeNumber()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number);

		// Confirm
		int expected = 26;
		int actual = target.getNumber();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor1_initializeGoals()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number);

		// Confirm
		int expected = 0;
		int actual = target.getGoals();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor1_initializeAssists()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number);

		// Confirm
		int expected = 0;
		int actual = target.getAssists();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	/*
	 * Constructor2 - HockeyPlayer(String, int, int, int)
	 */

	public static void constructor2_initializeName()
	{
		// Setup test data
		String name = "Mark";
		int number = 55;
		int goals = 2;
		int assists = 3;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Confirm
		String expected = "Mark";
		String actual = target.getName();

		System.out.printf("Expected: %s\nActual: %s\n", expected, actual);
	}

	public static void constructor2_initializeNumber()
	{
		// Setup test data
		String name = "Mark";
		int number = 55;
		int goals = 2;
		int assists = 3;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Confirm
		int expected = 55;
		int actual = target.getNumber();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor2_initializeGoals()
	{
		// Setup test data
		String name = "Mark";
		int number = 55;
		int goals = 2;
		int assists = 3;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Confirm
		int expected = 2;
		int actual = target.getGoals();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void constructor2_initializeAssists()
	{
		// Setup test data
		String name = "Mark";
		int number = 55;
		int goals = 2;
		int assists = 3;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Confirm
		int expected = 3;
		int actual = target.getAssists();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setName_updatesStateOfName()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		HockeyPlayer target = new HockeyPlayer(name, number);

		// Act
		target.setName("Mark");

		// Confirm
		String expected = "Mark";
		String actual = target.getName();

		System.out.printf("Expected: %s\nActual: %s\n", expected, actual);
	}

	public static void setNumber_updatesStateOfNumber()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;

		HockeyPlayer target = new HockeyPlayer(name, number);

		// Act
		target.setNumber(55);

		// Confirm
		int expected = 55;
		int actual = target.getNumber();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setGoals_updatesStateOfGoals()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;
		int goals = 1;
		int assists = 1;

		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Act
		target.setGoals(3);

		// Confirm
		int expected = 3;
		int actual = target.getGoals();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void setAssists_updatesStateOfAssists()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;
		int goals = 1;
		int assists = 1;

		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Act
		target.setAssists(4);

		// Confirm
		int expected = 4;
		int actual = target.getAssists();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void getPoints_returnsCorrectNumberOfPoints()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;
		int goals = 2;
		int assists = 3;

		// Act
		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Confirm
		int expected = 5;
		int actual = target.getPoints();

		System.out.printf("Expected: %d\nActual: %d\n", expected, actual);
	}

	public static void toString_returnsStringRepresentation()
	{
		// Setup test data
		String name = "Blake";
		int number = 26;
		int goals = 2;
		int assists = 3;

		HockeyPlayer target = new HockeyPlayer(name, number, goals, assists);

		// Act
		String actual = target.toString();

		// Confirm
		String expected = "Hockey Player - Blake [26], Points: 5";

		System.out.printf("Expected:%n%s%nActual:%n%s%n", expected, actual);
	}
}
